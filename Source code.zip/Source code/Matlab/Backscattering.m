% clc;clear;addpath(pwd,'m-files');addpath(pwd,'Data');close all;
% warning off��
% Calc=Backscattering_cal;
% R=330; %Radius of curvature
% d=10:5:150; %distance from the vertex to the detector
% angle=5; %tilt angle
% N=10000;  %number of sampling
% Calc.r1=2.5;% Detector size
%   for m=1:5
%  for i=1:size(d,2)
% Calc=Calc.Initialization(R,d(i));
% Calc= Calc.Mc_Backscattering(angle,N,R,d(i),0.0001,-2);
% Re_diff(i,m)=Calc.Flux;
% Re_BRDF(i,:,m)=Calc.STAT.BRDF;
% Re_Theta_i(i,:)=Calc.STAT.Theta_i;
% Re_Theta_s(i,:)=Calc.STAT.Theta_s;
% end
%   end
% %% %%%%%%%%%%%%%%% Plot Relevant quantities.
% %     Harvey_BRDF_plot(Calc,0.00028,-2,0) 
% %     Harvey_BRDF_plot(Calc,0.0001,-2,0)
% %%%     Harvey_BRDF_plot(Calc,0.001,-1.8,0)
% %% Plot the theta_i and theta_s
%  H=figure('Color',[1 1 1]);
%  T=axes;
%   plot(d,Re_Theta_i(:,1),'LineWidth',2,'Color',[0.24,0.35,0.67])
%   hold on
%     plot(d,Re_Theta_s(:,1),'LineWidth',2,'Color',[0.89,0.09,0.05])
%     errorbar(d(1:1:end),Re_Theta_s(1:1:end,1),Re_Theta_s(1:1:end,2),'.','LineWidth',1,'Color',[0.89,0.09,0.05])
%     errorbar(d(1:1:end),Re_Theta_i(1:1:end,1),Re_Theta_i(1:1:end,2),'.','Color',[0.24,0.35,0.67])
%     hold off
% xlabel('Distance d [mm]')
% ylabel('Angle of degree  [��]')
% axis([10 150 -18 8])
% grid on
% legend('{\Theta_i}','{\Theta_s}')
% set(gca,'Fontname','Palatino Linotype')
% set(gca,'Fontsize',15)
% set(gcf,'Position',[500 500 400 400]);
% set(gca,'Position',[.17 .17 .740 .740]);
% AA=min(abs(Re_Theta_s(:,2)-max(max(Re_Theta_s(:,2)))/(exp(1))));
% x=find(abs(Re_Theta_s(:,2)-max(max(Re_Theta_s(:,2)))/(exp(1)))==AA)
% % %% %% Plot of BRDF with d
% Result1=Read_data_from_ASAP('angle5_d10_150.txt');
% H=figure('Color',[1 1 1]);
% T=axes;
% plot(d,mean(Re_diff'),'LineWidth',2,'Color',[0.24,0.35,0.67])
% hold on
% plot(Result1(:,1),Result1(:,2),'LineWidth',2,'Color',[0.89,0.09,0.05])
% plot(d,std(Re_diff'),'r','LineWidth',2,'Color',[0.5,0.54,0.53])
% hold off
% set(T,'YScale','log')
% xlabel('Distance d [mm]')
% ylabel('Backscattering flux [W]')
% legend('Monte-Carlo','ASAP','Standard deviation')
% grid on
% set(gca,'Fontname','Palatino Linotype')
% set(gca,'Fontsize',15)
% set(gcf,'Position',[500 500 480 380]);
% set(gca,'Position',[.25 .17 .7 .8]);
% axis([10 150 10^-12 10^-3])
%%   %%%%%%%%%%%%%%%%%%%%%%%%%Calculate data with angle      
clc;clear;addpath(pwd,'m-files');close all;
warning off��
addpath('D:\Users\siliu\Desktop\Paper\Data')
Calc=Backscattering_cal;
R=330; %Radius of curvature
d=118; %distance from the vertex to the detector
Re.angle=linspace(1,15,15); %tilt angle
N=10000; %number of sampling
Calc.r1=2.5; % Detector size
for m=1:5
for i=1:size(Re.angle,2)
Calc=Calc.Initialization(R,d);
Calc= Calc.Mc_Backscattering(Re.angle(i),N,R,d,0.0001,-2);%%rms=0.36nm
Re.rms36(i,m)=Calc.Flux;
Re_BRDF36(i,:,m)=Calc.STAT.BRDF;
Re_Theta_i(i,:)=Calc.STAT.Theta_i;
Re_Theta_s(i,:)=Calc.STAT.Theta_s;
Calc= Calc.Mc_Backscattering(Re.angle(i),N,R,d,0.00028,-2);%%rms=0.6nm
Re.rms60(i,m)=Calc.Flux;
Re_BRDF60(i,:,m)=Calc.STAT.BRDF;
Re_Theta_i(i,:)=Calc.STAT.Theta_i;
Re_Theta_s(i,:)=Calc.STAT.Theta_s;
Calc= Calc.Mc_Backscattering(Re.angle(i),N,R,d,0.001,-1.8);%%rms=1.42nm
Re.rms142(i,m)=Calc.Flux;
Re_BRDF142(i,:,m)=Calc.STAT.BRDF;
Re_Theta_i(i,:)=Calc.STAT.Theta_i;
Re_Theta_s(i,:)=Calc.STAT.Theta_s;
end
end
Re.Ratio36=mean(Re.rms36')'./Re_BRDF36(:,1,1);
Re.Ratio60=mean(Re.rms60')'./Re_BRDF60(:,1,1);
Re.Ratio142=mean(Re.rms142')'./Re_BRDF142(:,1,1);
%% %%%%%%%%%%%%%%  plot data with angle
 Result1=Read_data_from_ASAP('D:\Users\siliu\Desktop\Paper\Data\r330d118b0001s_2a0_20.txt');
 Result2=Read_data_from_ASAP('D:\Users\siliu\Desktop\Paper\Data\r330d118b00027s_2a0_20.txt');
 Result3=Read_data_from_ASAP('D:\Users\siliu\Desktop\Paper\Data\r330d118b001s_18a0_20.txt');
H=figure('Color',[1 1 1]);
T=axes;
 plot(Re.angle,mean(Re.rms36'),'LineWidth',2,'Color',[0.24,0.35,0.67])
hold on
% plot(d,mean(Re_diff1'))
plot(Re.angle,mean(Re.rms60'),'--','LineWidth',2,'Color',[0.24,0.35,0.67])
plot(Re.angle,mean(Re.rms142'),':','LineWidth',2,'Color',[0.24,0.35,0.67])
plot(Result1(:,1),Result1(:,2),'-','LineWidth',2,'Color',[0.89,0.09,0.05])
plot(Result2(:,1),Result2(:,2),'--','LineWidth',2,'Color',[0.89,0.09,0.05])
plot(Result3(:,1),Result3(:,2),':','LineWidth',2,'Color',[0.89,0.09,0.05])
% plot(d,std(Re_diff'),'r','LineWidth',2,'Color',[0.5,0.54,0.53])
 axis([1 15 2*10^-11 10^-7])
hold off
set(T,'YScale','log')
xlabel('Tilt angle of the quaternary mirror  [��]')
ylabel('Backscattering flux [W]')
L=legend('Monte-Carlo RMS=0.36nm','Monte-Carlo RMS=0.6nm','Monte-Carlo RMS=1.42nm',...
    'ASAP RMS=0.36nm','ASAP RMS=0.6nm','ASAP RMS=1.42nm')
grid on
set(gca,'Fontname','Palatino Linotype')
set(gca,'Fontsize',15)
set(L,'Fontsize',12)
set(gcf,'Position',[510 500 500 380]);
set(gca,'Position',[.2 .16 .7 .8]);
set(L,'Location','northeastoutside');
%% plot data with angle
H=figure('Color',[1 1 1]);
T1=axes;
plot(Re.angle(1:end),Re.Ratio36(1:end),'*-','LineWidth',2,'Color',[0.24,0.35,0.67])
hold on
plot(Re.angle(1:end),Re.Ratio60(1:end),'^-','LineWidth',2,'Color',[0.89,0.09,0.05])
plot(Re.angle(1:end),Re.Ratio142(1:end),'s-','LineWidth',2)
hold off
set(T1,'YScale','log')
axis([3 15 8*10^-4 12*10^-4])
xlabel('Tilt angle of the quaternary mirror  [��]')
ylabel('Ratio of scattering flux to BRDF')
L=legend('RMS=0.36nm',' RMS=0.6nm',' RMS=1.42nm',...
    ' RMS=1nm')
grid on
set(gca,'Fontname','Palatino Linotype')
set(gca,'Fontsize',15)
set(L,'Fontsize',12)
set(gcf,'Position',[510 500 500 390]);
set(gca,'Position',[.2 .16 .7 .75]);
%%
 Plot_layout(Calc,330,118)