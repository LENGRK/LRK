classdef Backscattering_cal
    %UNTITLED �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
%       d  
      Center_rot
      Para_cal
      Flux
      STAT
      r1;%Detector size
      F21
      F12
      Fa21
      Fa12
    end
    properties (Constant)
%         R=330;
%         Rotangle=5;
         Mirror_size=4;
         P_tot=1; %Incident flux
         w0=1.875; % Beam waist
        
    end
    properties (Hidden)
        r
        h
        Mirror_func  
        alpha
        phi1
        M_pos
        D_pos
        SA
    end
    
    methods
        function obj=Initialization(obj,R,d)
            %UNTITLED ��������ʵ��
            %   �˴���ʾ��ϸ˵��
obj.phi1=0:1:360;
obj.h=linspace(sqrt(R^2-obj.Mirror_size^2),R,500);
obj.r=sqrt(R^2-obj.h.^2);
obj.alpha=asind(max(max(obj.r))/R);
%% Detector parameter
        end
 function obj = Mc_Backscattering(obj,Rotangle,N,R,d,b,s)
obj.Center_rot=XRot_matrix(d,Rotangle,[0,0,d-R],2); 
 %% Random point on mirror
 for i=1:N
  xr1=obj.r1;yr1=obj.r1;
  while sqrt(xr1^2+yr1^2)>obj.r1
  theta11=acosd(cosd(obj.alpha)+(cosd(0)-cosd(obj.alpha))*rand);    
  phi11=rand*360; 
  xr1=R*sind(theta11)*cosd(phi11);
  yr1=R*sind(theta11)*sind(phi11);
  zr1=R*cosd(theta11);
  end
  Pos=XRot_matrix(R,Rotangle,[xr1,yr1,zr1],1);
 %% Random point on detector     
xr2=(2*rand-1)*obj.r1;yr2=(2*rand-1)*obj.r1;
  while sqrt(xr2^2+yr2^2)>obj.r1
    xr2=(2*rand-1)*obj.r1;
    yr2=(2*rand-1)*obj.r1;
  end
A=[Pos(1),Pos(2),d+Pos(3)-R];%Postion of Mirror
B=[xr2,yr2,0];
obj.M_pos(i,:)=A;
obj.D_pos(i,:)=B;
S=sqrt((A(1)-B(1))^2+(A(2)-B(2))^2+(A(3)-B(3))^2);%distance
nor_vec=obj.Center_rot-A;nor_vec=nor_vec/norm(nor_vec);
Theta2=Ca_angle([0,0,1],A-B);% angle between detector normal and scattered ray
Theta1=Ca_angle(-nor_vec,A-B);% angle between mirror normal and scattered ray
Theta_i=Ca_angle(-nor_vec,[0,0,1]);% Incident angle
Theta_s_vec=[0,0,1]-2*dot([0,0,1],nor_vec)*(nor_vec);
Theta_s=-Ca_angle(nor_vec,B-A);%scattered angle to mirror
BRDF=Harvey(Theta_i,Theta_s,b,s);
power=2*obj.P_tot/pi/obj.w0^2*exp(-(2*(xr1^2+yr1^2).^2)/obj.w0^2);
obj.Para_cal.Theta_i(i,1)=Theta_i;
obj.Para_cal.Theta_s(i,1)=Theta_s;
if BRDF>Harvey(Theta_i,2*Rotangle,b,s)*10^2
    N=N-1;
continue
end
obj.Para_cal.BRDF(i,1)=BRDF; 
obj.Para_cal.Power(i,1)=power;
obj.Para_cal.kernel(i,1)=power*BRDF*cosd(Theta1)*cosd(Theta2)/S^2;
KK(i,1)=cosd(Theta1)*cosd(Theta2)/S^2;
SA=pi*(max(max(obj.r1))^2+(R-sqrt(R^2-max(max(obj.r1))^2))^2)/cosd(Rotangle);
obj.Flux=SA*pi*obj.r1^2/N*sum(obj.Para_cal.kernel(:));
KK1=SA*pi*obj.r1^2/N*sum(KK(:));
 end
obj.STAT.BRDF(1,1)=mean(obj.Para_cal.BRDF);
obj.STAT.BRDF(1,2)=std(obj.Para_cal.BRDF);
obj.STAT.Theta_s(1,1)=mean(obj.Para_cal.Theta_s);
obj.STAT.Theta_s(1,2)=std(obj.Para_cal.Theta_s);
obj.STAT.Theta_i(1,1)=mean(obj.Para_cal.Theta_i);
obj.STAT.Theta_i(1,2)=std(obj.Para_cal.Theta_i);
 end    
     
         function  Plot_layout(obj,R,d)
            %METHOD1 �˴���ʾ�йش˷�����ժҪ
            %   �˴���ʾ��ϸ˵��
          x=cosd(obj.phi1(:))*obj.r(:)';
          y=sind(obj.phi1(:))*obj.r(:)';
          z=ones(size(obj.phi1(:)))*(d-R+obj.h(:))';
           r11=0:obj.r1/300:obj.r1;
           x1=cosd(obj.phi1(:))*r11;
           y1=sind(obj.phi1(:))*r11;
           z1=ones(size(x1,1),size(x1,2))*0;
           figure
           mesh(x,y,z)
           hold on
           mesh(x1,y1,z1)
           step=1;
           for i=1:100:size(obj.M_pos,1)
           %% incident (blue rays)
           plot3([obj.M_pos(i,1),obj.M_pos(i,1)],[obj.M_pos(i,2)...
                ,obj.M_pos(i,2)],[0,obj.M_pos(i,3)],'Linewidth',0.1,'Color',[0 0 1])
           %% normal
%            plot3([obj.Center_rot(1),obj.M_pos(i,1)],[obj.Center_rot(2)...
%                ,obj.M_pos(i,2)],[obj.Center_rot(3),obj.M_pos(i,3)],'Linewidth',0.1,'Color','r')
           %% scatter (Red rays)
           plot3([obj.M_pos(i,1),obj.D_pos(i,1)],[obj.M_pos(i,2)...
               ,obj.D_pos(i,2)],[obj.M_pos(i,3),obj.D_pos(i,3)],'Linewidth',0.1,'Color',[1 0 0])
           end
           scatter3(obj.M_pos(1:step:end,1),obj.M_pos(1:step:end,2),obj.M_pos(1:step:end,3),2)
           scatter3(obj.D_pos(1:step:end,1),obj.D_pos(1:step:end,2),obj.D_pos(1:step:end,3),2)
           axis equal
           axis([-5 5 -5 5 0 d+10])
         end
         
         function Harvey_BRDF_plot(obj,b,s,angle)
            %METHOD1 �˴���ʾ�йش˷�����ժҪ
            %   �˴���ʾ��ϸ˵��
            %%
% load('Inplane_scatter.mat')
m=1;
% theta_i=5;
for theta_i=0:20:80
    k=1;
 for i=-85:0.5:85
     F(k)=Harvey(theta_i,i,b,s);
     k=k+1;
 end
 BRDF_H(m).theta_i=theta_i;
 BRDF_H(m).BRDF=F;
 m=m+1;
end
figure('Color',[1 1 1])
Inplane_scatter_Har=[-85:0.5:85;F]';
% semilogy(Inplane_scatter_Har(:,1),Inplane_scatter_Har(:,2),'LineWidth',1)
semilogy(-85:0.5:85,BRDF_H(1).BRDF,'LineWidth',2,'Color',[0.24,0.35,0.67])
hold on
for i=2:size(BRDF_H,2)
semilogy(-85:0.5:85,BRDF_H(i).BRDF,'LineWidth',2)
end
hold off
grid on
legend('{\Theta_i}=0��','{\Theta_i}=20��','{\Theta_i}=40��',...
    '{\Theta_i}=60��','{\Theta_i}=80��')
xlabel('Scattering angle [��]')
ylabel('BRDF [1/Sr]')
set(gca,'Fontname','Palatino Linotype')
set(gca,'Fontsize',15)
set(gcf,'Position',[510 500 500 390]);
set(gca,'Position',[.2 .16 .7 .75]);
axis([-90 90 5*10^-10 10^-2])
% fid=fopen('b1.txt','wt');
% fprintf(fid,'%d\n',theta_i);
% for i=1:201
% fprintf(fid,'%6.2f %12.12f\n',Inplane_scatter_Har(i,:));
% end
% fclose(fid);
% % save('b1.txt','Inplane_scatter_Har','-ascii')
X=0.001:0.01:85;
Y=Inplane_scatter_Har(:,2)';
Y=Harvey(angle,-85:0.5:85,b,s);
Tis=interp1(-85:0.5:85,Y,X).*cosd(X).*sind(X);
Tis(Tis==inf)=0;
Tis=trapz(X,Tis)*pi*2
1064/4/pi*sqrt(Tis)
  end
        
    end
end

