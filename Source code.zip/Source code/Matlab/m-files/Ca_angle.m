function theta_i = Ca_angle(A,B,C,D)
            switch nargin
                case 5 %angle between line AB and CD
 for i=1:size(A,1)
theta_i(i,1)=180-acosd(dot([A(i,1)-B(i,1), A(i,2)-B(i,2), B(i,3)-A(i,3)],[C(i,1)-D(i,1), C(i,2)-D(i,2), D(i,3)-C(i,3)])./...  
(norm([A(i,1)-B(i,1), A(i,2)-B(i,2), B(i,3)-A(i,3)]))./(norm([C(i,1)-D(i,1), C(i,2)-D(i,2), D(i,3)-C(i,3)])));  
 end
                    
                case 2
  for i=1:size(A,1)                  
theta_i(i,1)=acosd((A(i,1)*B(i,1)+A(i,2)*B(i,2)+A(i,3)*B(i,3))./norm(A(i,:))./norm(B(i,:)));
  end
end
end

