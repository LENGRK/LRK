function BRDF = Harvey(theta_i,theta_s,b,s,l)
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%   
 switch nargin
   case 4 %angle between line AB and CD
BRDF=b*(100*abs(sind(theta_s)-sind(theta_i))).^s;
   case 5 %angle between line AB and CD
BRDF=b*(abs(1+(sind(theta_s)/l))).^(s/2);
 end
% i=1;
% for T=-85:0.5:85;
% BRDF(i)=Harvey(10,T,0.005,-3,0.001)
% i=i+1;
% end
% figure
% semilogy(-85:0.5:85,BRDF)