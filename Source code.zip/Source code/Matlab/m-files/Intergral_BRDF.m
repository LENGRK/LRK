classdef Intergral_BRDF
    %UNTITLED �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    properties 
   d; %=R-118;
   Vec_angle
   Mirror1
   Mirror1_rot
   Center
   Incident_point
   Incident_vec
   normal_vec
   Refl_vec 
   S
   theta_i;
   theta2;
    end   
properties (Constant)
step1=1;
R=330;
r=20;
angle=10;
Detector_semi=10;
end
    
properties (Hidden)
theta;
phi;
Mirror_func
Detector_x
Detector_y
Detector_z
end
    
   
    
    
    methods
        function obj = Cal_angle(obj,A,B,C,D)
            switch nargin
                case 5
 for i=1:size(A,1)
 obj.theta_i(i,1)=180-acosd(dot([A(i,1)-B(i,1), A(i,2)-B(i,2), B(i,3)-A(i,3)],[C(i,1)-D(i,1), C(i,2)-D(i,2), D(i,3)-C(i,3)])./...  
(norm([A(i,1)-B(i,1), A(i,2)-B(i,2), B(i,3)-A(i,3)]))./(norm([C(i,1)-D(i,1), C(i,2)-D(i,2), D(i,3)-C(i,3)])));  
 end
                    
                case 3
  for i=1:size(A,1)                  
 obj.Vec_angle(i,1)=acosd((A(i,1)*B(i,1)+A(i,2)*B(i,2)+A(i,3)*B(i,3))./norm(A(i,:))./norm(B(i,:)));
  end
            end
        end
        
        function obj=Initialization(obj)
            %METHOD1 �˴���ʾ�йش˷�����ժҪ
            %   �˴���ʾ��ϸ˵��
obj.theta=0:obj.step1:180;
obj.phi=90-asind(obj.r/obj.R):obj.R/10000:90;
obj.d=obj.R-118;
obj.Center=[obj.R*sind(obj.angle),0,obj.R-obj.R*cosd(obj.angle)-obj.d];
[obj.theta,obj.phi]=meshgrid(obj.theta,obj.phi); 
 obj.Mirror1(:,:,1)=obj.R*cosd(2*obj.theta).*cosd(obj.phi);
 obj.Mirror1(:,:,2)=obj.R*sind(2*obj.theta).*cosd(obj.phi);
 obj.Mirror1(:,:,3)=obj.R*sind(obj.phi)-obj.d;  
  for i=1:size(obj.theta,1)
    for j=1:size(obj.phi,2)
        A=[obj.Mirror1(i,j,1),obj.Mirror1(i,j,3)];B=[0 obj.R-obj.d];
        A_new = rotateAround(A, B, obj.angle);
        obj.Mirror1_rot(i,j,1)=A_new(1);
        obj.Mirror1_rot(i,j,3)=A_new(2);
    end
end
obj.Mirror1_rot(:,:,2)=obj.Mirror1(:,:,2);    
A=obj.Mirror1_rot(:,:,1);
B=obj.Mirror1_rot(:,:,2);
C=obj.Mirror1_rot(:,:,3);
A=A(:);B=B(:);C=C(:);
obj.Mirror_func=scatteredInterpolant(A,B,C);
obj.Detector_x=-obj.Detector_semi:0.1:obj.Detector_semi;
obj.Detector_y=-obj.Detector_semi:0.1:obj.Detector_semi;
[obj.Detector_x,obj.Detector_y]=meshgrid(obj.Detector_x,obj.Detector_y);
obj.Detector_z=zeros(size(obj.Detector_x));
        end
        
function obj=Incident_point_Calc(obj,Detector_pos)
%METHOD1 �˴���ʾ�йش˷�����ժҪ
%   �˴���ʾ��ϸ˵��
obj.Incident_point=[Detector_pos(:,1),Detector_pos(:,2),obj.Mirror_func(Detector_pos(:,1),Detector_pos(:,2))];
obj.Center=obj.Center.*ones(size(obj.Incident_point));
obj.normal_vec=(obj.Center-obj.Incident_point);
obj.Incident_vec=[0,0,1].*ones(size(obj.Incident_point));
for i=1:size(obj.Incident_point,1)
obj.normal_vec(i,:)=obj.normal_vec(i,:)/norm(obj.normal_vec(i,:));
obj.Refl_vec(i,:)=(obj.Incident_vec(i,:)-2*dot(obj.Incident_vec(i,:),obj.normal_vec(i,:))*obj.normal_vec(i,:));
end
        end
%         
function  Plot_Con(obj)
 %METHOD1 �˴���ʾ�йش˷�����ժҪ
 %   �˴���ʾ��ϸ˵��
figure ('color',[1 1 1])
mesh(obj.Mirror1_rot(:,:,1),obj.Mirror1_rot(:,:,2),obj.Mirror1_rot(:,:,3))
hold on
mesh(obj.Detector_x,obj.Detector_y,obj.Detector_z);
plot3([0,obj.R*sind(obj.angle)],[0 0],[obj.R-obj.d obj.R-obj.R*cosd(obj.angle)-obj.d]);
axis equal;
for i = 1:size(obj.Incident_point,1)
plot3([obj.Incident_point(i,1),obj.Incident_point(i,1)],[obj.Incident_point(i,2),obj.Incident_point(i,2)],[0,obj.Incident_point(i,3)])  ; 
% plot3([obj.Incident_point(i,1),obj.R*sind(obj.angle)],[obj.Incident_point(i,2),0],[obj.Incident_point(i,3),obj.R-obj.R*cosd(obj.angle)-obj.d]);
quiver3(obj.Incident_point(i,1),obj.Incident_point(i,2),obj.Incident_point(i,3),obj.Refl_vec(i,1),obj.Refl_vec(i,2),obj.Refl_vec(i,3),150);
end
hold off
axis([-50 250 -50 50 -250 150]);
xlabel('x')
ylabel('y')
zlabel('z')
view([0 -1 0.3]);
end  
function  obj=Para_Calc(obj,A,B)
  obj.S=sqrt((A(:,1)-B(:,1)).^2+(A(:,2)-B(:,2)).^2+(A(:,3)-B(:,3)).^2)  
  obj.theta2=Ca_angle(repmat([0 0 1],size(A-B,1),1),B-A); w       
        end          

    end
end

