clc,clear,close all;
%% Import BSDF From ASAP generate txtfile 
pixel=201;
% fid=fopen('D:\baidupan\Ciomp\ASAP\lengshidabaoku\Export_txt\myfile1.txt');
fid=fopen('D:\baidupan\Trash\myfile2.txt')
A=textscan(fid,'%f');
fclose(fid);
% BSDF=exp(A);
B=A{1,1};C=B(pixel+1:end);C=reshape(C,pixel+1,pixel)';
Alpha=B(1:pixel,1)';Beta=C(:,1);BSDF=C(:,2:end);
BSDF(BSDF==BSDF(1,1))=nan;BSDF=10.^(BSDF);
[Alpha,Beta]=meshgrid(Alpha,Beta);
%%
figure
mesh(Alpha,Beta,BSDF)
xlabel('Alpha')
ylabel('Beta')
zlabel('BSDF(1/Sr)')
set(gca,'ZScale','log')
psi=atand(Alpha./Beta);
theta_s=asind(Alpha./sind(psi));
theta_s(:,(pixel+1)/2)=theta_s(:,(pixel-1)/2);
ind=~(imag(theta_s)==0);
theta_s(ind)=nan;
[x,y]=find(BSDF==max(max(BSDF)))
psi=abs(psi-90);
psi(1:(pixel-1)/2,:)=psi(1:(pixel-1)/2,:)+180;
%% specular point
psi(x,y) 
theta_s(x,y)
theta_s1=theta_s((pixel+1)/2,:);
theta_s1(1,1:(pixel+1)/2)=-theta_s1(1,1:(pixel+1)/2);
%% plot psi , theta_s, BSDF image
% figure
% imagesc(psi)
% figure
% imagesc(BSDF)
% figure
% imagesc(theta_s)
figure
Inplane_scatter=[theta_s1;BSDF((pixel+1)/2,:)]';
semilogy(Inplane_scatter(:,1),Inplane_scatter(:,2))
save Inplane_scatter