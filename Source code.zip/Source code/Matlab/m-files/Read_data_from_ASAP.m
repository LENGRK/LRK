function Result = Read_data_from_ASAP(filepath)
fidin=fopen(filepath);
i=1;k=1;
while ~feof(fidin)
    tline = fgetl(fidin);
    if mod(i,2)
    A=textscan(tline,'%s %s %f');
   Data1(k,1)=A(:,3);
%     A=textscan(tline,'%s %s %s %f');  
%     Data1(k,1)=A(:,4);
%     Data1(k,1)=A(:,4);
%      k=k+1;
    else
    B=textscan(tline,'%s %s %f');
    Data1(k,2)=B(:,3);
     k=k+1;
    end
    i=i+1;    
end
fclose all
Result=cell2mat([Data1(:,1),Data1(:,2)]);
end

