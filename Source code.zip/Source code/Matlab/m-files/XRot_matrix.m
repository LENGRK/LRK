function Pos= XRot_matrix(Y,angle,A,Mode)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% mode 1 rotate around x-axis
% mode 2 rotate ariund a point
switch Mode
    case 1
Shift1=[1,0,0,0;0,1,0,0;0,0,1,-Y;0,0,0,1];
Shift2=[1,0,0,0;0,1,0,0;0,0,1,Y;0,0,0,1];
Rota=[1,0,0 0;0,cosd(angle),-sind(angle),0;0,sind(angle),cosd(angle),0; 0,0,0,1];
Pos=Shift2*Rota*Shift1*[A(1),A(2),A(3),1]';
Pos=Pos(1:end-1)';
  case 2
      % downward switch Y first
Rota=[1,0,0 0;0,cosd(angle),-sind(angle),0;0,sind(angle),cosd(angle),0; 0,0,0,1];
Pos=Rota*[A(1),A(2),A(3)-Y,1]';
Pos=Pos(1:end-1)';
Pos(3)=Pos(3)+Y;
end
end

