function [Config_para] = ASAP_Pos_load(Name,paths)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
addpath(pwd,'m-files');
fid = fopen(paths,'r');
i=1;k=1;
while true
% line = fgetl(fid);
% str2num(line);
tline = fgetl(fid);
if ~isempty(strfind(tline,'Ray'))
    
  continue;
end
if ~isempty(strfind(tline,'Object'))
  continue;
end
if ~ischar(tline) 
  break;
end
Num=str2num(tline);
Config_para.PathOrder(i)=Num(1);
i=i+1;
if Num(1)==0
  clear fid;
  break;
end
end
i=1;count_sur=size(Config_para.PathOrder,2);
fid = fopen(paths,'r');
while true
% line = fgetl(fid);
% str2num(line);
tline = fgetl(fid);
if ~isempty(strfind(tline,'Ray'))
  continue;
end
if ~isempty(strfind(tline,'Object'))
  continue;
end
if ~ischar(tline) 
  break;
end
Num=str2num(tline);
try
eval([Name,'.p',num2str(count_sur-1-rem(i-1,count_sur)),'.pos(k,:)=Num(2:5);']);
catch
    1
end
k=floor(i/(size(Config_para.PathOrder,2)))+1;
i=i+1;
%
end
 fclose all;
end

