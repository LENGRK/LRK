function BRDF = Harvey(theta_i,theta_s,b,s,l)
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%   
 switch nargin
   case 4 %angle between line AB and CD
BRDF=b*(100*abs(sind(theta_s)-sind(theta_i))).^s;
   case 5 %angle between line AB and CD
BRDF=b*(1+((sind(theta_s)-sind(theta_i))./l).^2).^(s/2);
 end
 %Plot data
%  AOI=0:10:60;theta_s=-85:0.5:85;
% for i=1:size(AOI,2)
% BRDF1(:,i)=Harvey(AOI(i),theta_s,0.0027,-4.7765,0.3328)';
% end
% Leg='';
% figure('color',[1 1 1])
% for i=1:size(AOI,2)
%     semilogy(theta_s,BRDF1(:,i),'lineWidth',1.5)
% hold on
%     semilogy(theta_s,BRDF1(:,i),'lineWidth',1.5)
% % Leg={['AOI=',num2str(AOI(i))]}
% Leg=[Leg,{['AOI=',num2str(AOI(i))]}];
% end
% legend(Leg)
% hold off