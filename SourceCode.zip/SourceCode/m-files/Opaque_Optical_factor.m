classdef Opaque_Optical_factor
    %UNTITLED �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    properties
        Qss
        Qsp
        Qps
        Qpp
        Qpp_ss
        Qsp_ss
        Qps_ss
        theta_smin
        theta_smax
        step
    end
    properties(Constant,Hidden)
        n1=1
        n2=0.04+0.76j
%         theta_smin=-90
%         theta_smax=90
%         step=1
        Psi=0
        lambda=1064
    end
    
    methods
function obj = John(obj,theta_i)
        i=1;varepsilon1=obj.n1^2;varepsilon2=obj.n2^2;
        % for theta_s=theta_smin:(theta_smax-theta_smin)/339:theta_smax 
        for theta_s=obj.theta_smin:obj.step:obj.theta_smax 
        pre_factor=16*pi^2/obj.lambda^4*cosd(theta_i)*cosd(theta_s)^2;
        obj.Qss(i)=pre_factor*abs((varepsilon2-varepsilon1)*cosd(obj.Psi)/((cosd(theta_i)+sqrt(varepsilon2-varepsilon1*sind(theta_i)^2))*(cosd(theta_s)+sqrt(varepsilon2-varepsilon1*sind(theta_s)^2))))^2;
        obj.Qsp(i)=pre_factor*abs((varepsilon2-varepsilon1)*sqrt((varepsilon2-varepsilon1*sind(theta_s)^2))*sind(obj.Psi)/(cosd(theta_i)+sqrt(varepsilon2-varepsilon1*sind(theta_i)^2))*(varepsilon2*cosd(theta_s)+sqrt(varepsilon2-varepsilon1*sind(theta_s)^2)))^2;
        obj.Qps(i)=pre_factor*abs((varepsilon2-varepsilon1)*sqrt((varepsilon2-varepsilon1*sind(theta_i)^2))*sind(obj.Psi)/(varepsilon2*cosd(theta_i)+sqrt(varepsilon2-varepsilon1*sind(theta_i)^2))*(cosd(theta_s)+sqrt(varepsilon2-varepsilon1*sind(theta_s)^2)))^2;
        obj.Qpp(i)=abs((varepsilon2-varepsilon1)*((sqrt((varepsilon2-varepsilon1*sind(theta_i)^2)))*(sqrt(varepsilon2-varepsilon1*sind(theta_s)^2))*cosd(obj.Psi)-varepsilon2*sind(theta_i)*sind(theta_s)))^2;
        obj.Qpp(i)=pre_factor*obj.Qpp(i)/abs((varepsilon2*cosd(theta_i)+sqrt(varepsilon2-varepsilon1*sind(theta_i)^2))*(varepsilon2*cosd(theta_s)+sqrt(varepsilon2-varepsilon1*sind(theta_s)^2)))^2;
        i=i+1;
        end
end
function obj = Kienzle(obj,theta_1,phi)
n1=obj.n1;n2=obj.n2;
rs012=@(theta_1)(n1*cosd(theta_1)-sqrt(n2^2-n1^2*sind(theta_1)^2))/(n1*cosd(theta_1)+sqrt(n2^2-n1^2*sind(theta_1)^2));
rp012=@(theta_1)(n2^2*cosd(theta_1)-n1*sqrt(n2^2-n1^2*sind(theta_1)^2))/(n2^2*cosd(theta_1)+n1*sqrt(n2^2-n1^2*sind(theta_1)^2));
ts012=@(theta_1)2*n1*cosd(theta_1)/(n1*cosd(theta_1)+sqrt(n2^2-n1^2*sind(theta_1)^2));
tp012=@(theta_1)2*n1*n2*cosd(theta_1)/(n2^2*cosd(theta_1)+n1*sqrt(n2^2-n1^2*sind(theta_1)^2));
rs021=@(theta_1)(n2*cosd(theta_1)-sqrt(n1^2-n2^2*sind(theta_1)^2))/(n2*cosd(theta_1)+sqrt(n1^2-n2^2*sind(theta_1)^2));
rp021=@(theta_1)(n1^2*cosd(theta_1)-n2*sqrt(n1^2-n2^2*sind(theta_1)^2))/(n1^2*cosd(theta_1)+n2*sqrt(n1^2-n2^2*sind(theta_1)^2));
ts021=@(theta_1)2*n2*cosd(theta_1)/(n2*cosd(theta_1)+sqrt(n1^2-n2^2*sind(theta_1)^2));
tp021=@(theta_1)2*n2*n1*cosd(theta_1)/(n1^2*cosd(theta_1)+n2*sqrt(n1^2-n2^2*sind(theta_1)^2));
%%
i=1;varepsilon1=obj.n1^2;varepsilon2=obj.n2^2;
for theta_s=obj.theta_smin:obj.step:obj.theta_smax
theta_ss=asind(n1/n2*sind(theta_s));
obj.Qss(i)=abs(varepsilon1-varepsilon2)^2*(2*pi/obj.lambda)^4/(4*pi)^2/n1^2/cosd(theta_1)*...
    abs((1+rs012(theta_1))*(1+rs012(theta_s))*cosd(obj.Psi))^2;
 obj.Qsp(i)=abs(varepsilon1-varepsilon2)^2*(2*pi/obj.lambda)^4/(4*pi)^2/n1^2/cosd(theta_1)*...
      abs((1+rs012(theta_1))*(1-rp012(theta_s))*cosd(theta_s)*sind(obj.Psi))^2;
 obj.Qps(i)=abs(varepsilon1-varepsilon2)^2*(2*pi/obj.lambda)^4/(4*pi)^2/n1^2/cosd(theta_1)*...
      abs((1-rp012(theta_1))*(1+rs012(theta_s))*cosd(theta_1)*sind(obj.Psi))^2;
obj.Qpp(i)=abs(varepsilon1-varepsilon2)^2*(2*pi/obj.lambda)^4/(4*pi)^2/n1^2/cosd(theta_1)*...
    abs((1-rp012(theta_1))*(1-rp012(theta_s))*cosd(theta_1)*cosd(theta_s)*cosd(obj.Psi)...
    -1/varepsilon2*(1+rp012(theta_1))*(1+rp012(theta_s))*sind(theta_1)*sind(theta_s))^2;
i=i+1;
end
end

function scale_factor(obj,theta_i,phi)
    varepsilon=(obj.n2/obj.n1)^2
    theta_s=obj.theta_smin:obj.step:obj.theta_smax 
    obj.Qpp_ss=secd(phi)^2*(cosd(phi)*sqrt(varepsilon-sind(theta_i).^2).*sqrt(varepsilon-sind(theta_s).^2)...
        -varepsilon*sind(theta_i)*sind(theta_s)).^2/varepsilon^2;
    obj.Qsp_ss=tg(phi)^2*(varepsilon-sind(theta_s)^2)/varepsilon;
    obj.Qps_ss=tg(phi)^2*(varepsilon-sind(theta_i)^2)/varepsilon;
end
    end
end         

