classdef Roughness_Surface
    %UNTITLED3 �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        N %Spatial sampling number  
        d % spatial sampling gap  [\mu m] 
%       xn =-floor(N/2) : ceil(N/2)-1;     % Spatial vector
%       L=N*d;            % Spatial length [\mu m]
    end
    
    methods
 
function [Height,x,y]=ProfileG(obj,N,d,RMS,cl,dimension,Correlation)
  % nu is the spatial frequency in unit of [\mu m^-1]
  % PSD is the Power spatial density with is [nm^3] for 1D, [nm^4] for 2D
switch dimension
    case 1
        xn =-floor(N/2):ceil(N/2)-1;     % Spatial vector
        x=d*xn;
        Z=RMS.*randn(1,N); % uncorrelated Gaussian random rough surface distribution
        L=d*length(Z);
    if cl==0
        Height=Z;
    elseif Correlation=='G'
       F = exp(-x.^2/(cl^2/2));
       Height = sqrt(2/sqrt(pi))*sqrt(L/N/cl)*ifft(fft(Z).*fft(F));
    % [F1,nu1]= fourierminus(Z,x);
    % [F2,nu2]= fourierminus(F,x);
    % [Height,x]=fourierplus(F1.*F2,nu2) ;
    % Height=sqrt(2/sqrt(pi))*sqrt(L/N/cl)*Height;
    elseif Correlation=='E'
       F = exp(-abs(x)/(cl/2)); 
       Height = sqrt(2/sqrt(pi))*sqrt(L/N/cl)*ifft(fft(Z).*fft(F));
    % [F1,nu1]= fourierminus(Z,x);
    % [F2,nu2]= fourierminus(F,x);
    % [Height,x]=fourierplus(F1.*F2, nu2) ;
    %  Height=sqrt(2/sqrt(pi))*sqrt(L/N/cl)*real(Height);
    % %  Height=real(Height);
     end
    case 2
        xn =-floor(N/2):ceil(N/2)-1;     % Spatial vector
        yn =-floor(N/2):ceil(N/2)-1;     % Spatial vector
        x=d*xn; y=d*yn;
        [X,Y] = meshgrid(x,y); 
        Z = RMS.*randn(N,N); 
        L=d*length(Z);
        if size(cl,2)==1
          if cl==0
              Height=Z;
                 % with mean 0 and standard deviation h
          elseif Correlation=='G'
              F = exp(-((X.^2+Y.^2)/(cl^2/2)));
              Height = 2/sqrt(pi)*L/N/cl*ifft2(fft2(Z).*fft2(F));
          elseif Correlation=='E'
                % Gaussian filter
%              F = exp(-abs(x)/(cl/2));
%              f = sqrt(2)*sqrt(rL/N/cl)*ifft(fft(Z).*fft(F));
               F = exp(-(abs(X)+abs(Y))/(clx/2));
    % correlation of surface including convolution (faltung), inverse
    % Fourier transform and normalizing prefactors
    f = 2*rL/N/clx*ifft2(fft2(Z).*fft2(F));
          end
        else
        if cl(1)==0&&cl(2)==0
              Height=Z;
                 % with mean 0 and standard deviation 
        elseif  cl(1)==0||cl(2)==0
                cl(cl==0)=[];
              if Correlation=='G'
                  F = exp(-((X.^2+Y.^2)/(cl^2/2)));
                  Height= 2/sqrt(pi)*L/N/cl*ifft2(fft2(Z).*fft2(F));
              elseif Correlation=='E'
                    % Gaussian filter
                F = exp(-(abs(X)+abs(Y))/(cl/2));
                  Height = 2*L/N/cl*ifft2(fft2(Z).*fft2(F));
              end
        else
            if Correlation=='G'
              F = exp(-(X.^2/(cl(1)^2/2)+Y.^2/(cl(2)^2/2)));
              % correlated surface generation including convolution (faltning) and inverse
              % Fourier transform and normalizing prefactors
              Height=2/sqrt(pi)*L/N/sqrt(cl(1))/sqrt(cl(2))*ifft2(fft2(Z).*fft2(F));
            elseif Correlation=='E'
                % Gaussian filter
                F = exp(-(abs(X)/(cl(1)/2)+abs(Y)/(cl(2)/2)));
                Height = 2*L/N/sqrt(cl(1)*cl(2))*ifft2(fft2(Z).*fft2(F));
            end
        end
    
end

  end
end
        

function [RMS]=PSD2RMS(obj,nu1,PSD,dimension,nu2)
  % nu is the spatial frequency in unit of [\mu m^-1]
  % PSD is the Power spatial density with is [nm^3] for 1D, [nm^4] for 2D
  switch dimension
    case 1
    RMS=sqrt(trapz(nu1/10^3,PSD));
    case 2
    RMS=sqrt(trapz(nu2(:,1)',trapz(nu1(1,:),PSD*10^-12,1)));
    RMS=RMS*10^3;
      case 3
    RMS=sqrt(2*pi*trapz(nu/1000,nu/1000.*PSD));
  end
end


function [PSD,nu1,nu2]=Height2PSD(obj,Height,xn,yn)
  % N is Spatial sampling number  
  % d is spatial sampling gap  [\mu m] 
if nargin==3
%     xn =-floor(N/2):ceil(N/2)-1;  % Spatial vector
    N=length(xn);
    d=xn(2)-xn(1);
    L=N*d;            % Spatial length [\mu m]
    ave=mean(Height);
    [PSD,nu1]=fourierminus((Height-ave)*10^-3,xn);
    PSD=1/L*abs(PSD).^2*10^9;
%     nu1=nu1*10^3;
elseif nargin==4
%     xn =-floor(N/2):ceil(N/2)-1; % Spatial vector
%     yn =-floor(N/2):ceil(N/2)-1; % Spatial vector
    dx=xn(2)-xn(1);Lx=length(xn)*dx;
    dy=yn(2)-yn(1);Ly=length(yn)*dy;
    [xn,yn]=meshgrid(xn,yn);
              % Spatial length [\mu m]
    ave=mean(mean(Height));
    [PSD,nu1,nu2]=fourier2Dminus((Height-ave)*10^-3,xn,yn);
    PSD=1/Lx/Ly*abs(PSD).^2*10^12;    
end 
end

function [acf,cl,lags] = acf1D(obj,f,x,opt)
%
% [acf,cl,lags] = acf1D(f,x)
%
% calculates the autocovariance function and correlation length of a 
% 1-d surface profile f(x).
%
% Input:    f    - surface heights
%           x    - surface points
%           opt - optional parameter (type 'plot' for plotting the 
%                 normalized autocovariance function)
%
% Output:   acf  - autocovariance function
%           cl   - correlation length
%           lags - lag length vector (useful for plotting the acf)
%
% Last updated: 2010-07-26 (David Bergstrom)
%

format long

N = length(x); % number of sample points
lags = linspace(0,x(N)-x(1),N); % lag lengths

% autocovariance function calculation
c=xcov(f,'coeff'); % the autocovariance function
acf=c(N:2*N-1); % right-sided version

% correlation length calculation
k = 1;
while (acf(k) > 1/exp(1))
    k = k + 1;
end
cl = 1/2*(x(k-1)+x(k)-2*x(1)); % the correlation length

% optional plotting
if nargin<4 || isempty(opt)
    return;
end
if nargin==4
    if ischar(opt)
        if strcmp(opt,'plot')
            figure
            plot(lags,acf);
            xlabel('lag length')
            ylabel('acf (normalized)')
            title('Plot of the normalized acf')
        else fprintf('%s is not a valid option. Type \''help acf1D\'' for further details.\n',opt); 
        end
    else fprintf('Option must be a string. Type \''help acf1D\'' for further details.\n');
    end
end
end    

function [acfx,clx,acfy,cly,lags] = acf2D(obj,f,x,y,opt)
%
% [acfx,clx,acfy,cly,lags] = acf2D(f,x,y,opt)
%
% calculates the averaged autocovariance functions and correlation lengths
% of a 2-d surface f(x,y) in x and y directions.
%
% Input:    f    - surface heights
%           x    - surface points
%           y    - surface points
%           opt - optional parameter (type 'plot' for plotting the 
%                 normalized autocovariance functions)
%
% Output:   acfx - averaged autocovariance function in x direction
%           clx  - correlation length in x direction
%           acfy - averaged autocovariance function in y direction
%           cly  - correlation length in y direction
%           lags - lag length vector (useful for plotting the acfs)
%
% Last updated: 2010-07-29 (David Bergstrom)
%

format long

N = length(x); % number of sample points
lags = linspace(0,x(N)-x(1),N); % lag lengths

% autocovariance function calculation
acfx = zeros(1,N); acfy = zeros(1,N);
for i = 1:N
    cx = xcov(f(i,:),'coeff'); % the autocovariance function in x at row i
    acfx = acfx + cx(N:2*N-1)'; % right-sided version (cumulative sum)
    cy = xcov(f(:,i),'coeff'); % the autocovariance function in y at column i
    acfy = acfy + cy(N:2*N-1); % right-sided version (cumulative sum)
end

acfx = acfx / N; acfy = acfy / N; % averaging of acfs

% correlation lengths calculation
% in x
k = 1;
while (acfx(k) > 1/exp(1))
    k = k + 1;
end
clx = 1/2*(x(k-1)+x(k)-2*x(1)); % the correlation length in x
% in y
k = 1;
while (acfy(k) > 1/exp(1))
    k = k + 1;
end
cly = 1/2*(y(k-1)+y(k)-2*y(1)); % the correlation length in y

% optional plotting
if nargin<=4 || isempty(opt)
    return;
end
if nargin==5
    if ischar(opt)
        if strcmp(opt,'plot');
            subplot(1,2,1),plot(lags,acfx)
            xlabel('lag length (x)')
            ylabel('acf (normalized)')
            title('Plot of the average normalized acf in x-dir')
            subplot(1,2,2),plot(lags,acfy)
            xlabel('lag length (y)')
            ylabel('acf (normalized)')
            title('Plot of the average normalized acf in y-dir')
        else fprintf('%s is not a valid option. Type \''help acf2D\'' for further details.\n',opt); 
        end
    else fprintf('Option must be a string. Type \''help acf2D\'' for further details.\n');
    end
end
end

function [hdf,bc,h] = hdf1D(obj,f,b,opt)
%
% [hdf,bc,h] = hdf1D(f,b,opt)
%
% calculates the height distribution function and rms height of a 
% 1-d surface profile f(x) using b bins.
%
% Input:    f   - surface heights
%           b   - number of bins
%           opt - optional parameter (type 'hist' for drawing histogram,
%                 type 'plot' for continuous plot) 
%
% Output:   hdf - height distribution function
%           bc  - bin centers
%           h   - rms height
%
% Last updated: 2009-03-11 (David Bergstr?m)
%

format long

h = std(f); % rms height

[hdf,bc] = hist(f,b); 
hdf = hdf/sum(hdf); % normalization to get height distribution function

% optional plotting
if nargin<4 || isempty(opt)
    return;
end
if nargin==4
     figure('color',[1 1 1])
    if ischar(opt)
        if strcmp(opt,'hist')
            bar(bc,hdf);
            xlabel('surface height')
            ylabel('probability')
            title('Histogram of height distribution function for height of surface profile y=f(x)')
        elseif strcmp(opt,'plot');
            plot(bc,hdf);
            xlabel('surface height')
            ylabel('probability')
            title('Plot of height distribution function for height of surface profile y=f(x)')
        else fprintf('%s is not a valid option. Type \''help pmf1D\'' for further details.\n',opt);
        end
    else fprintf('Option must be a string. Type \''help pmf1D\'' for further details.\n');
    end
end
end

function [hdf,bc,h] = hdf2D(obj,f,b,opt)
%
% [hdf,bc,h] = hdf2D(f,b,opt)
%
% calculates the height distribution function and rms height of a 
% 2-d surface profile f(x,y) using b bins.
%
% Input:    f   - surface heights
%           b   - number of bins
%           opt - optional parameter (type 'hist' for drawing histogram,
%                 type 'plot' for continuous plot) 
%
% Output:   hdf - height distribution function
%           bc  - bin centers
%           h   - rms height
%
% Last updated: 2009-03-11 (David Bergstr?m)
%

format long

h = std2(f); % rms height

[hdf,bc] = hist(f,b); % histograms over columns
hdf = sum(hdf,2); % summing all histograms
hdf = hdf/sum(hdf); % normalization to get height distribution function
% figure('color',[1 1 1])
% optional plotting
if nargin<4 || isempty(opt)
    return;
end
if nargin==4
    if ischar(opt)
        
        if strcmp(opt,'hist')
            figure('color',[1 1 1])
            bar(bc,hdf);
            xlabel('surface height')
            ylabel('probability')
            title('Histogram of height distribution function for height of surface z=f(x,y)')
        elseif strcmp(opt,'plot')
            figure('color',[1 1 1])
            plot(bc,hdf);
            xlabel('surface height')
            ylabel('probability')
            title('Plot of height distribution function for height of surface z=f(x,y)')
        else fprintf('%s is not a valid option. Type \''help pmf2D\'' for further details.\n',opt);
        end
    else fprintf('Option must be a string. Type \''help pmf2D\'' for further details.\n');
    end
end
end

    end
end

