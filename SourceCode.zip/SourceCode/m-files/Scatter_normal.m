function [Normals] = Scatter_normal(X,Y,Z,sensorCenter)
%% X Y Z are the surface vectors
%% vector will towards sensorCenter
pc(:,1)=X';pc(:,2)=Y';pc(:,3)=Z';
ptCloud = pointCloud(pc);
normals=pcnormals(ptCloud);
x = ptCloud.Location(1:1:end,1);
y = ptCloud.Location(1:1:end,2);
z = ptCloud.Location(1:1:end,3);
u = normals(1:1:end,1);
v = normals(1:1:end,2);
w = normals(1:1:end,3);
for k = 1 : numel(x)
   p1 = sensorCenter - [x(k),y(k),z(k)];
   p2 = [u(k),v(k),w(k)];
   % Flip the normal vector if it is not pointing towards the sensor.
   angle = atan2(norm(cross(p1,p2)),p1*p2');
   if angle > pi/2 || angle < -pi/2
       u(k) = -u(k);
       v(k) = -v(k);
       w(k) = -w(k);
   end
end
Normals=[u,v,w];
end

