classdef Scattering_cal
    %UNTITLED3 �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
%        dis
       Pos
       space_para  
       scatter_para
       f
       deviation
    end
%     properties (Constant)
%        sensorCenter1= [0,0,300]; 
%     end
     properties (Hidden)
       sensorCenter1= [0,0,300]; 
       sensorCenter2= [0,0,-300]; 
    end
    methods   
          function obj = load_data(obj,path)
            obj.Pos=ASAP_Pos_load('Config_para',path);
           end
        
function obj = Surface_para(obj)
Num1=size(obj.Pos.PathOrder,2);
for i=1:Num1
eval(['obj.Pos.p',num2str(i)-1,'= Surfac_para(obj.Pos.p',num2str(i)-1,',obj.sensorCenter1)'])
end
end
        
function obj = Space_para(obj)
 RayVec01=obj.Pos.p1.pos-obj.Pos.p0.pos;
obj.space_para.dis=sum(abs((RayVec01)).^2,2).^(1/2);
RayVec01=RayVec01./sum(abs((obj.Pos.p1.pos-obj.Pos.p0.pos)).^2,2).^(1/2);
obj.space_para.theta01=Ca_angle(RayVec01,obj.Pos.p0.Normals);
obj.space_para.theta10=Ca_angle(RayVec01,obj.Pos.p1.Normals);
% Config_para1.p0.S=area_calc(Config_para1.p0.pos(:,1),Config_para1.p0.pos(:,3),Config_para1.p0.pos(:,2));
obj.space_para.Etendue01=abs(sum(cosd(obj.space_para.theta01).*cosd(obj.space_para.theta10)./(obj.space_para.dis.^2))...
*obj.Pos.p0.S*obj.Pos.p1.S/size(obj.Pos.p1.pos,1));
end

function obj = Plot_sactter(obj,step,a1,a2,C1,rays)
   figure('Color',[1 1 1])
eval(['A=[obj.Pos.p',num2str(a1),'.pos(1:step:end,1),obj.Pos.p',num2str(a2),'.pos(1:step:end,1)];']);
A=A';
eval(['B=[obj.Pos.p',num2str(a1),'.pos(1:step:end,2),obj.Pos.p',num2str(a2),'.pos(1:step:end,2)];']);
B=B';
eval(['C=[obj.Pos.p',num2str(a1),'.pos(1:step:end,3),obj.Pos.p',num2str(a2),'.pos(1:step:end,3)];']);
C=C';
 scatter3(A(1,:),B(1,:),C(1,:),2,'filled','r')
    hold on
 scatter3(A(2,:),B(2,:),C(2,:),2,'filled','r')
if rays==1
plot3(A,B,C,'Color',C1);
end
hold off
axis equal;
axis off;
    axis equal
    axis off
    hold off         
   end

function obj =Scatter_para(obj,b,s,l,a1,a2,a3)
%     figure('color',[1 1 1])
tot_sur=size(obj.Pos.PathOrder,2);
tot_sur=tot_sur-1:-1:0;
Scat_sur=find(obj.Pos.PathOrder<0);
if isempty(Scat_sur)
    obj.scatter_para=[];
else
    inc_vec=eval(['obj.Pos.p',num2str(tot_sur(Scat_sur+2)),...
        '.pos(:,1:3)-obj.Pos.p',num2str(tot_sur(Scat_sur)),'.pos(:,1:3)']);
    obj.scatter_para.theta_i=eval(['Ca_angle(a1*inc_vec,obj.Pos.p',num2str(tot_sur(Scat_sur)),'.Normals)']);
    Sca_vec=eval(['obj.Pos.p',num2str(tot_sur(Scat_sur)),'.pos(:,1:3)-obj.Pos.p',num2str(tot_sur(Scat_sur)+1),'.pos(:,1:3)']);
  obj.scatter_para.theta_s=a3*eval(['Ca_angle(a2*Sca_vec,obj.Pos.p',num2str(tot_sur(Scat_sur)),'.Normals)']);
   obj.scatter_para.BRDF=Harvey(obj.scatter_para.theta_i,obj.scatter_para.theta_s,b,s,l);
%    figure
% % obj.scatter_para.fig=hist(obj.scatter_para.BRDF,50);
% 1
%  [p,ci]=gamfit(log(obj.scatter_para.BRDF)-min(log(obj.scatter_para.BRDF)))
%  x=linspace(-18,-15,1000);
%  y=gampdf(p(1),p(2),x);
%  1
% plot(x,y,'LineWidth',2)
%  set(gca,'XScale','log')
%  set(gca,'YScale','log')
 end
           
        end
   
    end
end

