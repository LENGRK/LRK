function Config_para= Surfac_para(Config_para,sensorCenter1)
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% Config_para=Config_para;
Config_para.Normals=Scatter_normal(Config_para.pos(:,1),Config_para.pos(:,2),Config_para.pos(:,3),sensorCenter1);
% Config_para.theta01=Ca_angle(RayVec01,Config_para1.p0.Normals);
Config_para.S=area_calc(Config_para.pos(:,1),Config_para.pos(:,3),Config_para.pos(:,2));
end

